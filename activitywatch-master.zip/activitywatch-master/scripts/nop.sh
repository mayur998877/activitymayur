#!/bin/bash

echo "nop.bat was executed as a workaround for something"
